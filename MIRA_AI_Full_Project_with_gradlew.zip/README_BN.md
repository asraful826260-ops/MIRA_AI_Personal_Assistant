# MIRA AI — Android starter project

এই ZIP-এ একটি Android Studio/Gradle প্রজেক্ট এবং GitHub Actions APK build workflow আছে।

## এখন যা কাজের ভিত্তি হিসেবে আছে
- বাংলা Speech-to-Text (Android speech recognizer; ডিভাইস/Google speech service দরকার)
- Android Text-to-Speech (কণ্ঠ ডিভাইসের TTS engine-এর উপর নির্ভরশীল)
- YouTube খোলা
- Wi-Fi/Internet settings panel খোলা
- Bluetooth settings খোলা
- Flashlight toggle (ডিভাইস/permission সমর্থন করলে)
- Media volume বাড়ানো
- SMS composer খোলা; ব্যবহারকারী নিজে যাচাই করে পাঠাবেন
- গোলাপি/ডার্ক MIRA UI

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি একটি কার্যকর starter build, সম্পূর্ণ স্বয়ংক্রিয় AI ফোন-নিয়ন্ত্রক নয়।
- Gemini AI chat এখনো backend-এ যুক্ত করা হয়নি। নিরাপদ HTTPS backend তৈরি করে সেটি অ্যাপে যুক্ত করতে হবে।
- API key কখনো APK বা GitHub repository-তে রাখবেন না।
- Android নিরাপত্তার কারণে Wi-Fi সরাসরি ON/OFF, অন্য অ্যাপের ভেতরে স্বয়ংক্রিয় comment/post/message, বা সব ফোন-সেটিংস নিয়ন্ত্রণ করা যায় না। প্রয়োজন হলে Android-এর অনুমোদিত Settings screen খুলবে।
- Female voice পাওয়া যাবে কি না তা ফোনে ইনস্টল করা TTS voice-এর উপর নির্ভর করে।
- সব ভয়েস কমান্ডের জন্য প্রথমে microphone permission দিতে হবে।

## GitHub থেকে APK
1. ZIP extract করে এর ভেতরের সব ফাইল repository-র root-এ upload করুন।
2. `.github/workflows/android-build.yml`-ও upload হয়েছে কি না দেখুন।
3. GitHub repository > Actions > MIRA Android APK Build > Run workflow চাপুন।
4. সফল হলে workflow run-এর নিচে Artifacts থেকে `MIRA-AI-APK` ডাউনলোড করুন।

## লোকাল বিল্ড
Android Studio-তে এই ফোল্ডার Open করুন। Gradle sync সম্পন্ন হলে Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।


## Gradle launcher সম্পর্কে
এই ZIP-এ `gradlew` ও `gradlew.bat` bootstrap script আছে। প্রথমবার চালালে ইন্টারনেট থেকে Gradle 8.9 ডাউনলোড করে চালাবে। এটি standard `gradle-wrapper.jar`-ভিত্তিক wrapper নয়; নেটওয়ার্ক ও `curl`/`unzip` (Windows-এ PowerShell) প্রয়োজন। GitHub Actions-এ workflow এই `gradlew` স্ক্রিপ্ট ব্যবহার করে।
