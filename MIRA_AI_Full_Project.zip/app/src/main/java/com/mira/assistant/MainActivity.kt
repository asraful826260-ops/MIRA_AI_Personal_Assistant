package com.mira.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.provider.Settings
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingSpeech: ((String) -> Unit)? = null

    private val speechPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) startSpeechRecognition() }

    private val speechLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) pendingSpeech?.invoke(spoken)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { MiraScreen(
            onSpeak = { text -> speak(text) },
            onListen = { callback ->
                pendingSpeech = callback
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED) startSpeechRecognition()
                else speechPermission.launch(Manifest.permission.RECORD_AUDIO)
            },
            onAction = { command -> handleCommand(command) }
        ) }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            tts?.language = Locale("bn", "BD")
            // The device's installed TTS engine determines the available voice/gender.
        }
    }

    private fun speak(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mira_reply")
    }

    private fun startSpeechRecognition() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "MIRA-কে বলুন")
        }
        try { speechLauncher.launch(intent) } catch (_: Exception) { speak("ভয়েস ইনপুট চালু করা যাচ্ছে না।") }
    }

    private fun handleCommand(raw: String): String {
        val c = raw.lowercase(Locale.ROOT)
        return try {
            when {
                "youtube" in c || "ইউটিউব" in c -> {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")))
                    "YouTube খুলছি।"
                }
                "wifi" in c || "ওয়াইফাই" in c || "ওয়াইফাই" in c -> {
                    startActivity(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
                    "ইন্টারনেট ও Wi-Fi সেটিংস খুলেছি। এখান থেকে পরিবর্তন করুন।"
                }
                "bluetooth" in c || "ব্লুটুথ" in c -> {
                    startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                    "Bluetooth সেটিংস খুলেছি।"
                }
                "setting" in c || "সেটিংস" in c -> {
                    startActivity(Intent(Settings.ACTION_SETTINGS)); "ফোনের সেটিংস খুলেছি।"
                }
                "flash" in c || "torch" in c || "টর্চ" in c || "ফ্ল্যাশ" in c -> {
                    val cm = getSystemService(CAMERA_SERVICE) as CameraManager
                    val cameraId = cm.cameraIdList.firstOrNull { id ->
                        cm.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                    }
                    if (cameraId != null) {
                        val currentlyOn = torchOn
                        cm.setTorchMode(cameraId, !currentlyOn)
                        torchOn = !currentlyOn
                        if (torchOn) "ফ্ল্যাশলাইট চালু করেছি।" else "ফ্ল্যাশলাইট বন্ধ করেছি।"
                    } else "এই ফোনে ফ্ল্যাশলাইট পাওয়া যায়নি।"
                }
                "volume" in c || "ভলিউম" in c || "শব্দ" in c -> {
                    val am = getSystemService(AUDIO_SERVICE) as AudioManager
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                    "মিডিয়া ভলিউম বাড়িয়েছি।"
                }
                "message" in c || "sms" in c || "মেসেজ" in c -> {
                    startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")).apply {
                        putExtra("sms_body", "")
                    })
                    "মেসেজ অ্যাপ খুলেছি। পাঠানোর আগে নিজে নম্বর ও লেখা যাচাই করুন।"
                }
                else -> "এই কমান্ডটি এখনো যুক্ত করা হয়নি। অ্যাপ খোলা, Wi-Fi সেটিংস, Bluetooth, ফ্ল্যাশলাইট ও ভলিউম কমান্ড চেষ্টা করুন।"
            }
        } catch (e: Exception) { "এই কাজটি করা যায়নি। ফোনের অনুমতি বা Android সীমাবদ্ধতা পরীক্ষা করুন।" }
    }

    private var torchOn = false

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
fun MiraScreen(
    onSpeak: (String) -> Unit,
    onListen: ((String) -> Unit) -> Unit,
    onAction: (String) -> String
) {
    var input by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("হ্যালো! আমি MIRA। আমাকে বাংলায় কিছু বলুন।") }
    var history by remember { mutableStateOf(listOf("MIRA: হ্যালো! আমি MIRA। আমাকে বাংলায় কিছু বলুন।")) }
    val pink = Color(0xFFFF4FA3)
    val dark = Color(0xFF17101D)

    MaterialTheme(colorScheme = darkColorScheme(
        primary = pink, background = dark, surface = Color(0xFF261A2B),
        onPrimary = Color.White, onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF30152F), dark)))
                .padding(18.dp)
        ) {
            Text("MIRA AI", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("PERSONAL SMART ASSISTANT", color = pink, fontSize = 11.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(18.dp))
            Box(
                Modifier.fillMaxWidth().height(190.dp)
                    .background(Color(0xFF492044), RoundedCornerShape(28.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(92.dp).background(pink.copy(alpha = .18f), CircleShape), contentAlignment = Alignment.Center) {
                        Text("M", color = Color.White, fontSize = 54.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Your pink-haired AI companion", color = Color.White.copy(alpha = .8f), fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("কথোপকথন", color = pink, fontWeight = FontWeight.Bold)
            LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp)) {
                items(history.size) { index ->
                    Text(history[index], color = Color.White, modifier = Modifier
                        .fillMaxWidth().padding(vertical = 5.dp)
                        .background(Color(0xFF281D30), RoundedCornerShape(14.dp)).padding(12.dp))
                }
            }
            TextField(
                value = input, onValueChange = { input = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("MIRA-কে কিছু বলুন...") },
                shape = RoundedCornerShape(18.dp),
                trailingIcon = {
                    IconButton(onClick = {
                        if (input.isNotBlank()) {
                            val q = input
                            val result = onAction(q)
                            answer = result
                            history = history + "আপনি: $q" + "MIRA: $result"
                            onSpeak(result)
                            input = ""
                        }
                    }) { Icon(Icons.Default.Send, contentDescription = "Send", tint = pink) }
                },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFF281D30),
                    unfocusedContainerColor = Color(0xFF281D30),
                    focusedTextColor = Color.White, unfocusedTextColor = Color.White
                )
            )
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { onListen { spoken ->
                    val result = onAction(spoken)
                    history = history + "আপনি: $spoken" + "MIRA: $result"
                    onSpeak(result)
                } },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                colors = ButtonDefaults.buttonColors(containerColor = pink),
                shape = RoundedCornerShape(18.dp)
            ) {
                Icon(Icons.Default.Mic, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("কথা বলুন", fontSize = 16.sp)
            }
            Spacer(Modifier.height(6.dp))
            Text("নোট: AI চ্যাটের জন্য ব্যক্তিগত HTTPS backend সংযোগ করতে হবে।", color = Color.LightGray, fontSize = 10.sp)
        }
    }
}
