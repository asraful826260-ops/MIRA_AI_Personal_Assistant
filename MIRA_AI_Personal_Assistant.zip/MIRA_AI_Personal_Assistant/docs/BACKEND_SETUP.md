# MIRA AI chat backend contract

The Android client does not contain an AI provider secret. Configure a private HTTPS backend and set the Gradle project property `MIRA_BACKEND_URL` to its base URL.

## Request

`POST {MIRA_BACKEND_URL}/chat`

```json
{
  "message": "আজকের আবহাওয়া কেমন?",
  "language": "bn-BD",
  "history": [
    { "role": "user", "content": "হ্যালো" },
    { "role": "assistant", "content": "হ্যালো! কীভাবে সাহায্য করব?" }
  ]
}
```

## Response

```json
{
  "reply": "আপনার প্রশ্নের উত্তর এখানে..."
}
```

## Set the URL

For a local development build, add this to your user-level Gradle properties file (recommended; do not commit secrets):

```properties
MIRA_BACKEND_URL=https://your-domain.example
```

Alternatively, add the same property to the project's `gradle.properties` while testing, then remove it before sharing the source project. The endpoint must use HTTPS. The app calls only `/chat` and expects a JSON `reply` string.

## Security checklist

- Keep provider API keys on the server, never in Android source code or `BuildConfig`.
- Authenticate clients, apply request limits, validate message size, and monitor abuse.
- Do not log sensitive chat content unnecessarily.
- Use TLS and a privacy policy. Tell users what data the backend receives and how long it is retained.
- The included client is a generic HTTP contract; it is not a hosted backend and does not provide an AI model by itself.
