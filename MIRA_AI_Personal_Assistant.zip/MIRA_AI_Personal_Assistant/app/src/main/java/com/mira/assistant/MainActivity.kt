package com.mira.assistant

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.AudioManager.*
import android.media.session.MediaSession
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.mira.assistant.data.ChatApi
import com.mira.assistant.data.ChatHistoryStore
import com.mira.assistant.data.ChatMessage
import com.mira.assistant.service.VoiceSessionService
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.regex.Pattern

class MainActivity : ComponentActivity() {
    private var speechRecognizer: SpeechRecognizer? = null
    private var speechStateCallback: ((Boolean) -> Unit)? = null
    private var speechTextCallback: ((String) -> Unit)? = null
    private var micPermissionCallback: (() -> Unit)? = null
    private var cameraPermissionCallback: (() -> Unit)? = null
    private var textToSpeech: TextToSpeech? = null
    private var ttsReady = false
    private lateinit var historyStore: ChatHistoryStore

    private val micPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val next = micPermissionCallback
        micPermissionCallback = null
        if (granted) next?.invoke() else speechTextCallback?.invoke("Microphone permission was not granted.")
    }

    private val cameraPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val next = cameraPermissionCallback
        cameraPermissionCallback = null
        if (granted) next?.invoke()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        historyStore = ChatHistoryStore(this)
        textToSpeech = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) configureTts("bn-BD")
        }
        setContent { MiraApp(this) }
    }

    fun loadHistory(): List<ChatMessage> = historyStore.load()
    fun persistHistory(messages: List<ChatMessage>) = historyStore.save(messages)
    fun clearHistory() = historyStore.clear()

    fun startVoiceRecognition(languageTag: String, onState: (Boolean) -> Unit, onText: (String) -> Unit) {
        speechStateCallback = onState
        speechTextCallback = onText
        val start = { startVoiceRecognitionNow(languageTag) }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            start()
        } else {
            micPermissionCallback = start
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startVoiceRecognitionNow(languageTag: String) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speechStateCallback?.invoke(false)
            speechTextCallback?.invoke("Speech recognition is not available on this device. Install or enable a speech recognition service.")
            return
        }
        runCatching {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) { speechStateCallback?.invoke(true) }
                    override fun onBeginningOfSpeech() = Unit
                    override fun onRmsChanged(rmsdB: Float) = Unit
                    override fun onBufferReceived(buffer: ByteArray?) = Unit
                    override fun onEndOfSpeech() = Unit
                    override fun onError(error: Int) {
                        stopVoiceSessionService()
                        speechStateCallback?.invoke(false)
                        if (error != SpeechRecognizer.ERROR_CLIENT) {
                            speechTextCallback?.invoke("Voice recognition stopped (code $error). Please try again.")
                        }
                    }
                    override fun onResults(results: Bundle?) {
                        stopVoiceSessionService()
                        speechStateCallback?.invoke(false)
                        val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                        if (!spoken.isNullOrBlank()) speechTextCallback?.invoke(spoken)
                        else speechTextCallback?.invoke("I did not catch that. Please try again.")
                    }
                    override fun onPartialResults(partialResults: Bundle?) = Unit
                    override fun onEvent(eventType: Int, params: Bundle?) = Unit
                })
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageTag)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            startVoiceSessionService()
            speechRecognizer?.startListening(intent)
        }.onFailure {
            stopVoiceSessionService()
            speechStateCallback?.invoke(false)
            speechTextCallback?.invoke("Could not start voice recognition: ${it.localizedMessage ?: "unknown error"}")
        }
    }

    fun stopVoiceRecognition() {
        runCatching { speechRecognizer?.cancel() }
        stopVoiceSessionService()
        speechStateCallback?.invoke(false)
    }

    private fun startVoiceSessionService() {
        val intent = Intent(this, VoiceSessionService::class.java)
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        }
    }

    private fun stopVoiceSessionService() {
        runCatching { stopService(Intent(this, VoiceSessionService::class.java)) }
    }

    fun speak(text: String, languageTag: String) {
        if (!ttsReady) return
        configureTts(languageTag)
        textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mira-${System.currentTimeMillis()}")
    }

    private fun configureTts(languageTag: String) {
        val tts = textToSpeech ?: return
        val requested = Locale.forLanguageTag(languageTag)
        var result = tts.setLanguage(requested)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            if (requested.language == "bn") result = tts.setLanguage(Locale.forLanguageTag("bn-IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale.US)
            }
        }
        // Prefer a voice explicitly labelled female if the installed TTS engine exposes one.
        val voices = tts.voices.orEmpty()
        val femaleVoice: Voice? = voices.firstOrNull {
            it.locale.language == requested.language && it.name.contains("female", ignoreCase = true)
        }
        if (femaleVoice != null) tts.voice = femaleVoice
    }

    fun getLaunchableApps(): List<LaunchableApp> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
            .mapNotNull { info ->
                val packageName = info.activityInfo?.packageName ?: return@mapNotNull null
                val label = info.loadLabel(packageManager)?.toString() ?: packageName
                LaunchableApp(label, packageName)
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    fun launchApp(packageName: String): String {
        return try {
            val launch = packageManager.getLaunchIntentForPackage(packageName)
                ?: return "That app cannot be opened from the launcher."
            startActivity(launch)
            "Opening app."
        } catch (_: Exception) {
            "Could not open that app."
        }
    }

    fun handleCommand(raw: String, onConfirmationRequired: (label: String, actionKey: String) -> Unit = { _, _ -> }): String? {
        val command = normalizeDigits(raw.lowercase(Locale.ROOT).trim())
        if (command.isBlank()) return "Please say or type a command."

        if (containsAny(command, "flashlight on", "torch on", "turn on flashlight", "টর্চ চালু", "ফ্ল্যাশলাইট চালু", "লাইট জ্বালাও", "লাইট চালু")) {
            turnTorch(true)
            return "Trying to turn on the flashlight. Camera permission may be required."
        }
        if (containsAny(command, "flashlight off", "torch off", "turn off flashlight", "টর্চ বন্ধ", "ফ্ল্যাশলাইট বন্ধ", "লাইট বন্ধ", "লাইট নিভাও")) {
            turnTorch(false)
            return "Trying to turn off the flashlight."
        }
        if (containsAny(command, "open wi-fi", "open wifi", "wifi settings", "ওয়াইফাই সেটিংস", "ওয়াইফাই সেটিংস", "ওয়াইফাই খোলো")) {
            return openSystemPage(Intent(Settings.ACTION_WIFI_SETTINGS), "Wi-Fi settings")
        }
        if (containsAny(command, "open bluetooth", "bluetooth settings", "ব্লুটুথ সেটিংস", "ব্লুটুথ খোলো")) {
            return openSystemPage(Intent(Settings.ACTION_BLUETOOTH_SETTINGS), "Bluetooth settings")
        }
        if (containsAny(command, "open settings", "phone settings", "সেটিংস খোলো", "ফোন সেটিংস")) {
            return openSystemPage(Intent(Settings.ACTION_SETTINGS), "Settings")
        }
        if (containsAny(command, "battery", "battery level", "চার্জ কত", "ব্যাটারি", "চার্জ দেখাও")) {
            val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val percent = if (level >= 0 && scale > 0) (level * 100 / scale) else -1
            return if (percent >= 0) "Battery is at $percent percent." else "Battery information is unavailable."
        }
        if (containsAny(command, "volume up", "increase volume", "শব্দ বাড়াও", "ভলিউম বাড়াও", "ভলিউম বাড়াও")) {
            (getSystemService(AUDIO_SERVICE) as AudioManager).adjustStreamVolume(STREAM_MUSIC, ADJUST_RAISE, FLAG_SHOW_UI)
            return "Media volume increased."
        }
        if (containsAny(command, "volume down", "decrease volume", "শব্দ কমাও", "ভলিউম কমাও")) {
            (getSystemService(AUDIO_SERVICE) as AudioManager).adjustStreamVolume(STREAM_MUSIC, ADJUST_LOWER, FLAG_SHOW_UI)
            return "Media volume decreased."
        }
        if (containsAny(command, "mute", "শব্দ বন্ধ", "মিউট")) {
            (getSystemService(AUDIO_SERVICE) as AudioManager).adjustStreamVolume(STREAM_MUSIC, ADJUST_MUTE, FLAG_SHOW_UI)
            return "Media volume muted."
        }
        if (containsAny(command, "unmute", "শব্দ চালু", "আনমিউট")) {
            (getSystemService(AUDIO_SERVICE) as AudioManager).adjustStreamVolume(STREAM_MUSIC, ADJUST_UNMUTE, FLAG_SHOW_UI)
            return "Media volume unmuted."
        }
        if (containsAny(command, "play music", "pause music", "next song", "আগের গান", "গান চালাও", "গান বন্ধ", "মিউজিক চালাও", "মিউজিক বন্ধ")) {
            val key = if (containsAny(command, "pause", "বন্ধ", "stop")) android.view.KeyEvent.KEYCODE_MEDIA_PAUSE else android.view.KeyEvent.KEYCODE_MEDIA_PLAY
            val manager = getSystemService(AUDIO_SERVICE) as AudioManager
            val down = android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, key)
            val up = android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, key)
            manager.dispatchMediaKeyEvent(down)
            manager.dispatchMediaKeyEvent(up)
            return "Sent a media playback command to the active player, if supported."
        }
        if (containsAny(command, "set alarm", "alarm", "অ্যালার্ম", "এলার্ম")) {
            val time = Regex("(\\d{1,2})[:.](\\d{2})").find(command)
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                if (time != null) {
                    putExtra(AlarmClock.EXTRA_HOUR, time.groupValues[1].toInt().coerceIn(0, 23))
                    putExtra(AlarmClock.EXTRA_MINUTES, time.groupValues[2].toInt().coerceIn(0, 59))
                }
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            }
            return openSystemPage(intent, "Clock alarm")
        }
        if (containsAny(command, "set timer", "timer", "টাইমার", "টাইমার দাও")) {
            val match = Regex("(\\d{1,3})\\s*(minutes?|mins?|seconds?|secs?|মিনিট|সেকেন্ড)").find(command)
            val amount = match?.groupValues?.get(1)?.toIntOrNull()
            val unit = match?.groupValues?.get(2).orEmpty()
            val seconds = if (amount == null) 0 else if (unit.startsWith("sec") || unit == "সেকেন্ড") amount else amount * 60
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                if (seconds > 0) putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            }
            return openSystemPage(intent, "Clock timer")
        }
        if (containsAny(command, "call ", "make a call", "phone ", "কল করো", "ফোন করো", "কল দাও")) {
            onConfirmationRequired("Open the phone dialer? MIRA will not place a call.", "dialer")
            return "For safety, confirm before opening the dialer. No call will be made automatically."
        }
        if (containsAny(command, "send message", "text ", "message ", "sms", "মেসেজ পাঠাও", "এসএমএস")) {
            onConfirmationRequired("Open your messaging app? MIRA will not send a message.", "messages")
            return "Please confirm. MIRA will only open your messaging app; it will not send anything."
        }
        if (command.startsWith("open ") || command.startsWith("launch ") || command.startsWith("খোলো ") || command.startsWith("চালু কর ")) {
            val query = command.removePrefix("open ").removePrefix("launch ").removePrefix("খোলো ").removePrefix("চালু কর ").trim()
            val match = getLaunchableApps().firstOrNull {
                it.label.lowercase(Locale.ROOT).contains(query) || it.packageName.lowercase(Locale.ROOT).contains(query)
            }
            if (match != null) return launchApp(match.packageName)
            return "I could not find an installed app matching '$query'. Use the Apps button to browse installed apps."
        }
        return null
    }

    fun performConfirmedAction(actionKey: String): String = when (actionKey) {
        "dialer" -> openSystemPage(Intent(Intent.ACTION_DIAL), "Phone dialer")
        "messages" -> openSystemPage(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING), "Messaging app")
        else -> "Unknown action."
    }

    private fun turnTorch(enabled: Boolean) {
        val applyTorch: () -> Unit = {
            runCatching {
                val cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                    cameraManager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                }
                if (cameraId != null) cameraManager.setTorchMode(cameraId, enabled)
            }
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            applyTorch()
        } else {
            cameraPermissionCallback = applyTorch
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun openSystemPage(intent: Intent, label: String): String = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        "Opening $label."
    } catch (_: ActivityNotFoundException) {
        "This phone does not provide a compatible $label screen."
    } catch (_: Exception) {
        "Could not open $label."
    }

    private fun normalizeDigits(text: String): String = buildString {
        text.forEach { character ->
            val index = "০১২৩৪৫৬৭৮৯".indexOf(character)
            append(if (index >= 0) ('0'.code + index).toChar() else character)
        }
    }

    private fun containsAny(text: String, vararg terms: String): Boolean = terms.any { text.contains(it) }

    override fun onDestroy() {
        stopVoiceRecognition()
        speechRecognizer?.destroy()
        speechRecognizer = null
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
        super.onDestroy()
    }
}

data class LaunchableApp(val label: String, val packageName: String)
private data class PendingConfirmation(val label: String, val actionKey: String)

@Composable
private fun MiraApp(activity: MainActivity) {
    val colors = darkColorScheme(
        primary = Color(0xFFE879F9),
        secondary = Color(0xFFA78BFA),
        background = Color(0xFF10091D),
        surface = Color(0xFF21152F),
        onBackground = Color(0xFFF8F1FF),
        onSurface = Color(0xFFF8F1FF)
    )
    MaterialTheme(colorScheme = colors) {
        var language by remember { mutableStateOf("bn-BD") }
        var input by remember { mutableStateOf("") }
        var listening by remember { mutableStateOf(false) }
        var busy by remember { mutableStateOf(false) }
        var micEnabled by remember { mutableStateOf(true) }
        var settingsOpen by remember { mutableStateOf(false) }
        var appsOpen by remember { mutableStateOf(false) }
        var pendingConfirmation by remember { mutableStateOf<PendingConfirmation?>(null) }
        val messages = remember { mutableStateListOf<ChatMessage>().apply { addAll(activity.loadHistory()) } }
        val scrollState = rememberScrollState()

        LaunchedEffect(messages.size) {
            activity.persistHistory(messages.toList())
            scrollState.animateScrollTo(scrollState.maxValue)
        }

        fun addMessage(role: String, content: String) {
            messages.add(ChatMessage(role, content))
            if (messages.size > 80) messages.removeAt(0)
        }

        fun sendMessage(text: String) {
            val clean = text.trim()
            if (clean.isEmpty() || busy) return
            input = ""
            addMessage("user", clean)
            val commandReply = activity.handleCommand(clean) { label, key ->
                pendingConfirmation = PendingConfirmation(label, key)
            }
            if (commandReply != null) {
                addMessage("assistant", commandReply)
                activity.speak(commandReply, language)
                return
            }
            busy = true
            val historySnapshot = messages.toList()
            activity.lifecycleScope.launch {
                val reply = ChatApi.ask(clean, language, historySnapshot)
                addMessage("assistant", reply)
                activity.speak(reply, language)
                busy = false
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF130B22), Color(0xFF24113C), Color(0xFF10091D))))
                .systemBarsPadding()
        ) {
            Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.weight(1f)) {
                        Text("MIRA AI", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                        Text("PERSONAL SMART ASSISTANT", fontSize = 9.sp, letterSpacing = 2.sp, color = Color(0xFFC4B5FD))
                    }
                    Surface(shape = RoundedCornerShape(30.dp), color = if (listening) Color(0xFF7C2D92) else Color(0xFF2A1D3A)) {
                        Text(
                            if (listening) "● LISTENING" else "● READY",
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            color = if (listening) Color(0xFFFFC5F7) else Color(0xFFB8F7D3),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(Modifier.height(10.dp))
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    val transition = rememberInfiniteTransition(label = "miraGlow")
                    val scale by transition.animateFloat(
                        initialValue = 0.96f,
                        targetValue = 1.04f,
                        animationSpec = infiniteRepeatable(tween(1500), RepeatMode.Reverse),
                        label = "avatarScale"
                    )
                    Box(
                        Modifier.size(120.dp).scale(scale)
                            .background(Brush.radialGradient(listOf(Color(0xFFEC72FF), Color(0xFF8B5CF6), Color(0xFF38215D))), CircleShape)
                            .border(2.dp, Color(0xFFEE9CFF), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("✦", fontSize = 55.sp, color = Color.White)
                    }
                }
                Text(
                    if (listening) "I'm listening… / শুনছি…" else "Hello! আমি MIRA. কীভাবে সাহায্য করব?",
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 8.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    color = Color(0xFFE9D5FF),
                    fontSize = 13.sp
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    LanguageChip("বাংলা", language == "bn-BD") { language = "bn-BD" }
                    LanguageChip("English", language == "en-US") { language = "en-US" }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { settingsOpen = true }) {
                        Icon(Icons.Default.Settings, null, tint = Color(0xFFE9D5FF), modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Settings", color = Color(0xFFE9D5FF), fontSize = 12.sp)
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    QuickButton("Apps", Icons.Default.Apps, Modifier.weight(1f)) { appsOpen = true }
                    QuickButton("Volume", Icons.Default.VolumeUp, Modifier.weight(1f)) {
                        (activity.getSystemService(Context.AUDIO_SERVICE) as AudioManager)
                            .adjustStreamVolume(STREAM_MUSIC, ADJUST_RAISE, FLAG_SHOW_UI)
                        addMessage("assistant", "Media volume increased.")
                    }
                    QuickButton("Flashlight", Icons.Default.FlashOn, Modifier.weight(1f)) {
                        val reply = activity.handleCommand("flashlight on") { _, _ -> }
                        addMessage("assistant", reply ?: "Flashlight command sent.")
                    }
                    QuickButton("Battery", Icons.Default.BatteryFull, Modifier.weight(1f)) {
                        val reply = activity.handleCommand("battery") { _, _ -> }
                        addMessage("assistant", reply ?: "Battery information unavailable.")
                    }
                }

                Spacer(Modifier.height(8.dp))
                Text("CONVERSATION", color = Color(0xFFBFA7DC), fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                Divider(color = Color(0xFF4B3468), modifier = Modifier.padding(top = 5.dp, bottom = 6.dp))

                if (messages.isEmpty()) {
                    Column(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Chat, null, tint = Color(0xFF9F82C5), modifier = Modifier.size(34.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("Try: ‘ওয়াইফাই সেটিংস খোলো’", color = Color(0xFFD8C8EB), fontSize = 13.sp)
                        Text("Or: ‘Open YouTube’", color = Color(0xFF9F82C5), fontSize = 12.sp)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(messages) { message ->
                            MessageBubble(message)
                        }
                    }
                }

                if (pendingConfirmation != null) {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF38214D)), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text(pendingConfirmation!!.label, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                                Button(onClick = {
                                    val outcome = activity.performConfirmedAction(pendingConfirmation!!.actionKey)
                                    addMessage("assistant", outcome)
                                    activity.speak(outcome, language)
                                    pendingConfirmation = null
                                }) { Text("Confirm") }
                                TextButton(onClick = { pendingConfirmation = null }) { Text("Cancel", color = Color.White) }
                            }
                        }
                    }
                }

                if (busy) Text("MIRA is thinking…", color = Color(0xFFC4B5FD), fontSize = 11.sp, modifier = Modifier.padding(vertical = 4.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Message MIRA… / লিখুন…", fontSize = 12.sp) },
                        singleLine = true,
                        shape = RoundedCornerShape(24.dp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { sendMessage(input) })
                    )
                    IconButton(onClick = { sendMessage(input) }, enabled = input.isNotBlank() && !busy) {
                        Icon(Icons.Default.Send, "Send", tint = Color(0xFFE879F9))
                    }
                    Surface(
                        shape = CircleShape,
                        color = if (listening) Color(0xFF9D174D) else Color(0xFF7C3AED),
                        modifier = Modifier.size(52.dp).clickable(enabled = micEnabled) {
                            if (listening) {
                                activity.stopVoiceRecognition()
                                listening = false
                            } else {
                                activity.startVoiceRecognition(language, { listening = it }, { spoken ->
                                    if (spoken.startsWith("Voice recognition stopped") || spoken.startsWith("Could not") || spoken.startsWith("Microphone permission") || spoken.startsWith("I did not catch")) {
                                        addMessage("assistant", spoken)
                                    } else {
                                        sendMessage(spoken)
                                    }
                                })
                            }
                        }
                    ) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Icon(if (listening) Icons.Default.Close else Icons.Default.Mic, if (listening) "Stop listening" else "Speak", tint = Color.White)
                        }
                    }
                }
                Text(
                    if (micEnabled) "Mic starts only after you tap. No background or screen-off wake-word listening." else "Microphone disabled in MIRA settings.",
                    color = Color(0xFF907DA8), fontSize = 9.sp, modifier = Modifier.padding(start = 4.dp, top = 3.dp, bottom = 2.dp)
                )
            }
        }

        if (settingsOpen) {
            AlertDialog(
                onDismissRequest = { settingsOpen = false },
                title = { Text("MIRA settings") },
                text = {
                    Column {
                        Text("Microphone control", fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (micEnabled) "Voice input enabled" else "Voice input disabled", modifier = Modifier.weight(1f))
                            TextButton(onClick = { micEnabled = !micEnabled; if (!micEnabled) activity.stopVoiceRecognition() }) {
                                Text(if (micEnabled) "Disable" else "Enable")
                            }
                        }
                        Divider(color = Color(0xFF5A4770))
                        Spacer(Modifier.height(8.dp))
                        Text("AI backend: ${if (BuildConfig.MIRA_BACKEND_URL.isBlank()) "Not configured" else "Configured"}")
                        Spacer(Modifier.height(6.dp))
                        Text("Wake word while screen is off is not enabled. Speech input runs only after you tap the mic. The installed phone TTS voice and language support determine the speaking voice.", fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                        TextButton(onClick = {
                            activity.clearHistory()
                            messages.clear()
                            settingsOpen = false
                        }) { Text("Clear encrypted chat history", color = Color(0xFFFF9BCB)) }
                    }
                },
                confirmButton = { TextButton(onClick = { settingsOpen = false }) { Text("Done") } }
            )
        }

        if (appsOpen) {
            val installedApps = remember { activity.getLaunchableApps() }
            AlertDialog(
                onDismissRequest = { appsOpen = false },
                title = { Text("Installed apps") },
                text = {
                    LazyColumn(Modifier.heightIn(max = 420.dp)) {
                        items(installedApps) { app ->
                            Text(
                                app.label,
                                modifier = Modifier.fillMaxWidth().clickable {
                                    val result = activity.launchApp(app.packageName)
                                    addMessage("assistant", "${app.label}: $result")
                                    appsOpen = false
                                }.padding(vertical = 11.dp),
                                color = Color.White
                            )
                            Divider(color = Color(0xFF49375D))
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { appsOpen = false }) { Text("Close") } }
            )
        }
    }
}

@Composable
private fun LanguageChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (selected) Color(0xFF7C3AED) else Color(0xFF2B1A3C),
        modifier = Modifier.clickable { onClick() }
    ) {
        Text(label, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = Color.White, fontSize = 11.sp)
    }
}

@Composable
private fun QuickButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    FilledTonalButton(onClick = onClick, modifier = modifier.height(58.dp), contentPadding = PaddingValues(horizontal = 4.dp, vertical = 5.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(icon, null, modifier = Modifier.size(18.dp))
            Text(label, fontSize = 9.sp, maxLines = 1)
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val user = message.role == "user"
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
        Surface(
            color = if (user) Color(0xFF6336A1) else Color(0xFF2A1C3A),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.widthIn(max = 300.dp)
        ) {
            Column(Modifier.padding(horizontal = 12.dp, vertical = 9.dp)) {
                Text(if (user) "YOU" else "MIRA", color = Color(0xFFD9B8FF), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(3.dp))
                Text(message.content, color = Color.White, fontSize = 13.sp)
            }
        }
    }
}
