package com.mira.assistant.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

/** Stores chat history encrypted with a key protected by Android Keystore. */
class ChatHistoryStore(context: Context) {
    private val prefs = runCatching {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "mira_private_chat_history",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }.getOrNull()

    fun load(): List<ChatMessage> = runCatching {
        val raw = prefs?.getString(KEY_MESSAGES, "[]") ?: "[]"
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                add(
                    ChatMessage(
                        role = item.optString("role", "assistant"),
                        content = item.optString("content", ""),
                        timestamp = item.optLong("timestamp", 0L)
                    )
                )
            }
        }
    }.getOrDefault(emptyList())

    fun save(messages: List<ChatMessage>) {
        runCatching {
            val array = JSONArray()
            messages.takeLast(80).forEach { message ->
                array.put(
                    JSONObject()
                        .put("role", message.role)
                        .put("content", message.content)
                        .put("timestamp", message.timestamp)
                )
            }
            prefs?.edit()?.putString(KEY_MESSAGES, array.toString())?.apply()
        }
    }

    fun clear() {
        runCatching { prefs?.edit()?.remove(KEY_MESSAGES)?.apply() }
    }

    companion object {
        private const val KEY_MESSAGES = "messages"
    }
}
