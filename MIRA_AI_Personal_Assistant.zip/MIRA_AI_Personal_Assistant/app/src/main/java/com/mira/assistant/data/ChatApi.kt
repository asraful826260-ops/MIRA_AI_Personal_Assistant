package com.mira.assistant.data

import com.mira.assistant.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object ChatApi {
    /** Calls your own HTTPS backend. No API secret is embedded in the APK. */
    suspend fun ask(message: String, language: String, history: List<ChatMessage>): String =
        withContext(Dispatchers.IO) {
            val baseUrl = BuildConfig.MIRA_BACKEND_URL.trim().trimEnd('/')
            if (baseUrl.isBlank()) {
                return@withContext if (language == "bn-BD") {
                    "AI চ্যাট চালু করতে প্রথমে docs/BACKEND_SETUP.md অনুযায়ী একটি HTTPS backend সেটআপ করে MIRA_BACKEND_URL দিন। ফোনের কমান্ডগুলো আলাদাভাবে কাজ করে।"
                } else {
                    "AI chat is not connected yet. Set up an HTTPS backend as described in docs/BACKEND_SETUP.md and configure MIRA_BACKEND_URL. Phone commands work separately."
                }
            }

            var connection: HttpURLConnection? = null
            try {
                val payload = JSONObject()
                    .put("message", message)
                    .put("language", language)
                    .put("history", JSONArray().apply {
                        history.takeLast(12).forEach { item ->
                            put(JSONObject().put("role", item.role).put("content", item.content))
                        }
                    })

                connection = (URL("$baseUrl/chat").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 12_000
                    readTimeout = 20_000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Accept", "application/json")
                }
                connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val status = connection.responseCode
                val stream = if (status in 200..299) connection.inputStream else connection.errorStream
                val responseText = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (status !in 200..299) return@withContext "AI server error ($status). Check the backend logs and HTTPS URL."
                val response = JSONObject(responseText)
                response.optString("reply").takeIf { it.isNotBlank() }
                    ?: "The AI server returned an empty reply."
            } catch (_: Exception) {
                "Could not reach the AI backend. Check your internet connection and backend URL."
            } finally {
                connection?.disconnect()
            }
        }
}
