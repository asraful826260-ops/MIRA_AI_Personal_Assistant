# MIRA AI – Personal Smart Assistant

এটি Redmi Note 12R / Android 13-এর জন্য একটি **Native Kotlin + Jetpack Compose Android Studio starter project**। এতে বাস্তব Android intent/API ব্যবহার করা হয়েছে; শুধু স্ক্রিনের নকশা নয়।

## এখন যে কাজগুলো করা আছে

- বাংলা (`bn-BD`) ও ইংরেজি (`en-US`) speech recognition — ব্যবহারকারী মাইক্রোফোন বোতাম চাপলে।
- Android-এর Text-to-Speech দিয়ে উত্তর পড়ে শোনানো। ইনস্টল করা TTS engine-এ female voice থাকলে সেটি অগ্রাধিকার পায়; সব ফোনে female Bengali voice নিশ্চিত নয়।
- বাংলা/ইংরেজি UI, chat history এবং purple/pink dark UI। Chat history Android Keystore-সুরক্ষিত encrypted preferences-এ রাখা হয়; Settings থেকে মুছতে পারবেন।
- Installed app list থেকে অ্যাপ খোলা।
- Torch on/off (Camera permission প্রয়োজন), media volume up/down/mute, Wi‑Fi ও Bluetooth settings খোলা, phone settings খোলা, battery level পড়া।
- Clock app-এর মাধ্যমে alarm ও timer তৈরি করা।
- Media key event দিয়ে সমর্থিত music player নিয়ন্ত্রণের চেষ্টা। প্লেয়ারভেদে কাজের ফল আলাদা হতে পারে।
- Call/message-এর ক্ষেত্রে confirmation দেখায়। অ্যাপ নিজে কল করে না বা মেসেজ পাঠায় না; শুধু dialer/messaging app খোলে।
- Tap-to-talk সেশনের সময় visible foreground-service notification।

## যেগুলো এখনো সম্পূর্ণ নয়

1. **“Hey MIRA” screen-off wake word:** এই ZIP-এ চালু নেই। Android 13/MIUI-তে সাধারণ অ্যাপের SpeechRecognizer দিয়ে নির্ভরযোগ্য screen-off hotword চালানো যায় না। এর জন্য আলাদা on-device hotword engine, model/license, battery testing এবং ডিভাইসভিত্তিক কাজ লাগবে। তাই MIRA গোপনে বা সবসময় মাইক্রোফোন চালু রাখে না।
2. **General AI chat:** নিজের HTTPS backend সংযুক্ত না করা পর্যন্ত সাধারণ প্রশ্নের AI উত্তর আসবে না। Backend-এর API format `docs/BACKEND_SETUP.md`-এ আছে। কোনো API key APK-তে রাখা হয়নি।
3. **APK:** এই environment-এ Android SDK/Gradle build toolchain পাওয়া যায়নি, তাই APK build বা Android 13-এ device test করা সম্ভব হয়নি। কোনো ভুয়া APK দেওয়া হয়নি। Android Studio থেকে APK build করতে হবে।

## Android Studio দিয়ে চালু করার নিয়ম

1. ZIP extract করুন।
2. Android Studio খুলে **Open** চাপুন এবং `MIRA_AI_Personal_Assistant` folder নির্বাচন করুন।
3. Android Studio-তে JDK 17 নির্বাচন করুন এবং Gradle Sync সম্পন্ন হতে দিন। প্রথমবার Gradle ও Android dependencies ইন্টারনেট থেকে নামবে।
4. Android SDK Platform 35 ইনস্টল করুন; ফোনে চালানোর জন্য Android 13 (API 33) বা নতুন emulator/device ব্যবহার করুন।
5. ফোনে Developer options ও USB debugging চালু করে USB দিয়ে যুক্ত করুন, অথবা APK build করে ফোনে ইনস্টল করুন।
6. প্রথমবার mic বোতাম চাপলে Microphone permission দিন। Flashlight command দিলে Camera permission চাইবে। Notification অনুমতি দিলে voice session notification দেখা সহজ হবে।
7. **Build → Build Bundle(s) / APK(s) → Build APK(s)** নির্বাচন করুন। সফল হলে সাধারণত `app/build/outputs/apk/debug/app-debug.apk` পাওয়া যাবে।

## দরকারি ভয়েস কমান্ড

- `ওয়াইফাই সেটিংস খোলো` / `Open Wi-Fi settings`
- `ব্লুটুথ সেটিংস` / `Open Bluetooth settings`
- `টর্চ চালু` / `Flashlight on`
- `টর্চ বন্ধ` / `Flashlight off`
- `ভলিউম বাড়াও` / `Volume up`
- `ভলিউম কমাও` / `Volume down`
- `ব্যাটারি` / `Battery`
- `অ্যালার্ম ৭:৩০` / `Set alarm 7:30`
- `টাইমার ৫ মিনিট` / `Set timer 5 minutes`
- `Open YouTube` বা `Open WhatsApp` (ইনস্টল করা থাকলে)
- `কল করো` / `Send message` — confirmation-এর পর dialer বা messaging app খুলবে; স্বয়ংক্রিয়ভাবে কল/মেসেজ হবে না।

Speech recognition-এর ভাষা ও ফলাফল ফোনে থাকা recognition service এবং internet availability-এর উপর নির্ভর করতে পারে।

## Privacy

- Mic কেবল ব্যবহারকারী mic বোতাম চাপলে সক্রিয় voice session শুরু করে।
- Screen-off wake word বা stealth recording নেই।
- Chat history encrypted storage-এ রাখা হয়; Settings থেকে clear করা যায়।
- AI backend-এ chat পাঠালে message ও সাম্প্রতিক conversation context আপনার নির্ধারিত backend-এ যাবে। Backend-এর privacy policy নিজে যাচাই করুন।
- Sensitive permission Android-এর system prompt দিয়ে চাওয়া হয়। Android lock screen bypass করা হয় না।
